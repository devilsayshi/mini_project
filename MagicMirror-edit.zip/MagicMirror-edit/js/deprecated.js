module.exports = {
	configs: ["kioskmode"]
};
